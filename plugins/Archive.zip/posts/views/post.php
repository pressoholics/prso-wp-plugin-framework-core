<?php
/**
* Pressoholics Custom Posts Pluign View.
*
* Handles requests for creating custom posts
*
*/

class PrsoPostsViewPost extends PrsoPostsFunctions {
	
	private	$post_key	= null; //Cache the unique option data array key for current custom post type
	
	function __construct( $get_data = array() ) {
		
		//Set view title
		$this->box_options_slug = $this->get_slug( 'box_options_slug' );
		
		//Cache get data
		$this->data['get'] = $get_data;
		
		//Init database array in class $data var
		$this->data[ $this->box_options_slug ] = array();
		
		//If this is an edit action get the post_key and use as data array key
		if( isset($this->data['get']['action']) && $this->data['get']['action'] === 'edit' ) {		
			if( isset($this->data['get']['post_key']) ) {
				//Cache key
				$this->post_key = $this->data['get']['post_key'];
				
				//Get page options from database and store for later
				$this->get_options( $this->box_options_slug, $this->post_key );
			}
		}
		
		//If this is an delete action get the post_key and get all option data for this controller
		if( isset($this->data['get']['action']) && $this->data['get']['action'] === 'delete' ) {		
			if( isset($this->data['get']['post_key']) ) {
				//Cache key
				$this->post_key = $this->data['get']['post_key'];
				
				//Get page options from database and store for later
				$this->get_options( $this->box_options_slug );
			}
		}		
		
	}
	
	public function add() {
	
		//Init helper classes
		global $PrsoAdmin;
		global $PrsoFlash;
		
		//Call method to create form settings
		$this->create_settings();
		
		?>
		<div class="wrap">
			<?php screen_icon( 'options-general' ); ?>
			<h2><?php echo $this->plugin_index_page_title; ?></h2>
			
			<!-- Output jquery to active field validation messages !-->
			<?php 
				echo $PrsoFlash->get_validate_flash(); 
			?>
			
			<?php
			//Output table of current custom fields
			//echo $this->current_fields_table();
			//Create an action button that links to controller => box, action => add
			echo $PrsoAdmin->button( 'New field', array( 'page_slug' => $this->get_slug( 'plugin_index_page_slug' ), 'controller' => 'field', 'action' => 'add', 'class' => 'button-primary', 'type' => null ) );
			?>
			
		</div>
		
		<div class="wrap">
			<form action="<?php echo $this->form_action( 'save_post' ); ?>" method="post">
				
				<!-- Form sections !-->
				<?php do_settings_sections( $this->box_options_slug ); ?>
				
				<p class="submit">
					<input class="button-primary" name="Submit" type="submit" value="Save Changes" />
				</p>
			</form>
		</div>
		<?php
		
	}
	
	public function edit() {
		
		//Carryout any specific edit functions then call add action
		$this->add();
		
	}
	
	public function delete() {
		
		global $PrsoFlash;
		
		//Set default flash message
		$PrsoFlash->set_flash( 'There was a problem deleting the box.', 'error' );
		
		//Check that the box key isset
		if( !empty($this->post_key) ) {
			
			//Confirm user can delete posts
			if( current_user_can( 'administrator' ) ) {
				
				//Now check that the options data array is not empty
				if( !empty( $this->data[$this->box_options_slug] ) && is_array( $this->data[$this->box_options_slug] ) ) {
				
					//Finally unset post_key data from options data array
					if( array_key_exists( $this->post_key, $this->data[$this->box_options_slug] ) ) {
						unset( $this->data[$this->box_options_slug][$this->post_key] );
						
						//Now update the options data
						update_option( $this->box_options_slug, $this->data[$this->box_options_slug] );
						
						//Set flash message
						$PrsoFlash->set_flash( 'Fields Box Deleted.', 'success' );
					}
				
				}
				
			}
			
		}
		
		//Redirect to the fields plugin home
		$this->plugin_redirect();
	}
	
	/**
	* setup_sections
	* 
	* Add section options array to $output to create a new section
	*
	* See the commented example within function.
	* 
	* @access 	private
	* @author	Ben Moody
	*/
	private function setup_sections() {
		
		//Init vars
		$output = array(); //Cache all sections setup arrays
		
		/*
		$output[] = array(
			'id' 		=> $this->get_slug('general_options'),
			'title'		=> ''
		);
		*/
		
		// ADD YOUR SECTIONS HERE //
		
		//General options section
		$output[] = array(
			'id' 	=> $this->get_slug('post_general_options'),
			'title'	=> 'General Options'
		);
		$output[] = array(
			'id' 	=> $this->get_slug('post_label_options'),
			'title'	=> 'Label Options'
		);
		$output[] = array(
			'id' 	=> $this->get_slug('post_menu_options'),
			'title'	=> 'Menu Options'
		);
		$output[] = array(
			'id' 	=> $this->get_slug('post_capability_options'),
			'title'	=> 'Capability Options'
		);
		$output[] = array(
			'id' 	=> $this->get_slug('post_advanced_options'),
			'title'	=> 'Advanced Options'
		);
		
		// END SECTIONS //
		
		if( !empty($output) ) {
			return $output;
		} else {
			return false;
		}
		
	}
	
	/**
	* setup_fields
	* 
	* Add field options array to $output to create a new section field
	*
	* See the commented example within function.
	*
	* 'type' is required as this is used by the admin model (in presso plugin) to decide how to output the form element html.
	* 
	* 	'type' Options: text, textarea, select, checkbox
	* 
	* @access 	private
	* @author	Ben Moody
	*/
	private function setup_fields() {
		
		//Init vars
		$output = array(); //Cache all sections setup arrays
		
		/*
		$output[] = array(
			'section' 	=> $this->get_slug('general_options'),
			'id'		=> $this->get_slug('field_legal_html'),
			'title'		=> '',
			'desc'		=> '',
			'type'		=> '',
			'default'	=> ''
		);
		*/
		
		
		// ADD YOUR FIELDS HERE //
		
			/**
			* General Options
			**/
			//Post Type Field
			$output[] = array(
				'section' 	=> $this->get_slug('post_general_options'),
				'id'		=> 'post_type',
				'title'		=> 'Post Type - $post_type',
				'desc'		=> 'REQ - Post type. (max. 20 characters, can not contain capital letters or spaces)',
				'type'		=> 'text',
				'default'	=> 'post_type'
			);
			//Post Type Description
			$output[] = array(
				'section' 	=> $this->get_slug('post_general_options'),
				'id'		=> 'description',
				'title'		=> 'Description - $args[description]',
				'desc'		=> 'Optional - A short descriptive summary of what the post type is',
				'type'		=> 'text_area',
				'default'	=> '',
				'array_key'	=> 'args'
			);
			//Post Type Public
			$output[] = array(
				'section' 	=> $this->get_slug('post_general_options'),
				'id'		=> 'public',
				'title'		=> 'Public - $args[public]',
				'desc'		=> 'Optional - Whether a post type is intended to be used publicly either via the admin interface or by front-end users',
				'type'		=> 'checkbox',
				'default'	=> '',
				'array_key'	=> 'args'
			);
			//Post Type excluded from search
			$output[] = array(
				'section' 	=> $this->get_slug('post_general_options'),
				'id'		=> 'exclude_from_search',
				'title'		=> 'Exclude from Search - $args[exclude_from_search]',
				'desc'		=> 'Optional - Whether to exclude posts with this post type from front end search results.',
				'type'		=> 'checkbox',
				'default'	=> '',
				'array_key'	=> 'args'
			);
			//Post Type hierarchical
			$output[] = array(
				'section' 	=> $this->get_slug('post_general_options'),
				'id'		=> 'hierarchical',
				'title'		=> 'Hierarchical - $args[hierarchical]',
				'desc'		=> 'Optional - Whether the post type is hierarchical (e.g. page). Allows Parent to be specified.',
				'type'		=> 'checkbox',
				'default'	=> '',
				'array_key'	=> 'args'
			);
			//Post Type supports
			$post_features = array(
				'Title' 		=> 'title',
				'Editor'		=> 'editor',
				'Author'		=> 'author',
				'Featured image'	=> 'thumbnail',
				'Excerpt'		=> 'excerpt',
				'Trackbacks'	=> 'trackbacks',
				'Custom fields'	=> 'custom-fields',
				'Comments'		=> 'comments',
				'Revisions'		=> 'revisions',
				'Page Attributes'	=> 'page-attributes',
				'Post Formats'	=> 'post-formats'
			);
			$output[] = array(
				'section' 	=> $this->get_slug('post_general_options'),
				'id'		=> 'supports',
				'title'		=> 'Supports - $args[supports][]',
				'desc'		=> 'Optional - An alias for calling add_post_type_support() directly.',
				'type'		=> 'multi-checkbox',
				'default'	=> '',
				'choices'	=> $post_features,
				'array_key'	=> 'args'
			);
			/**
			* END - General Options
			**/
			
			/**
			* Label Options
			**/
			//Post Type Label
			$output[] = array(
				'section' 	=> $this->get_slug('post_label_options'),
				'id'		=> 'label',
				'title'		=> 'Label - $args[label]',
				'desc'		=> 'Optional - A plural descriptive name for the post type marked for translation.',
				'type'		=> 'text',
				'default'	=> '',
				'array_key'	=> 'args'
			);
			//Post Type labels
			$post_labels = array(
				'Singular name'				=> 'singular_name',
				'Add New [?]'				=> 'add_new',
				'All [?]'					=> 'all_items',
				'Add New [?]'				=> 'add_new_item',
				'Edit [?]'					=> 'edit_item',
				'New [?]'					=> 'new_item',
				'View [?]'					=> 'view_item',
				'Search [?]s'				=> 'search_items',
				'No [?] found'				=> 'not_found',
				'No [?]s found in trash'	=> 'not_found_in_trash',				
				'Menu Name'					=> 'menu_name'
			);
			$output[] = array(
				'section' 	=> $this->get_slug('post_label_options'),
				'id'		=> 'labels',
				'title'		=> 'Labels - $args[labels][]',
				'desc'		=> 'Optional - An array of labels for this post type. By default post labels are used for non-hierarchical types and page labels for hierarchical ones.',
				'type'		=> 'multi-text',
				'default'	=> '',
				'choices'	=> $post_labels,
				'array_key'	=> 'args'
			);
			/**
			* END - Label Options
			**/
			
			/**
			* Menu Options
			**/
			//Show in menu
			$output[] = array(
				'section' 	=> $this->get_slug('post_menu_options'),
				'id'		=> 'show_in_menu',
				'title'		=> 'Show in Menu - $args[show_in_menu]',
				'desc'		=> 'Optional true/false/"page string" - If an existing top level page such as "tools.php" or "edit.php?post_type=page", the post type will be placed as a sub menu of that.',
				'type'		=> 'text',
				'default'	=> '',
				'array_key'	=> 'args'
			);
			//Menu Position
			$menu_position = array(
				'below Posts' 		=> 5,
				'below Media' 		=> 10,
				'below Links' 		=> 15,
				'below Pages' 		=> 20,
				'below comments' 		=> 25,
				'below first separator' 		=> 60,
				'below Plugins' 		=> 65,
				'below Users' 		=> 70,
				'below Tools' 		=> 75,
				'below Settings' 		=> 80,
				'below second separator' 		=> 100
			);
			$output[] = array(
				'section' 	=> $this->get_slug('post_menu_options'),
				'id'		=> 'menu_position',
				'title'		=> 'Menu Position - $args[menu_position]',
				'desc'		=> 'Optional - The position in the menu order the post type should appear. show_in_menu must be true.',
				'type'		=> 'select',
				'default'	=> 20,
				'choices'	=> $menu_position,
				'array_key'	=> 'args'
			);
			//Menu Icon URL
			$output[] = array(
				'section' 	=> $this->get_slug('post_menu_options'),
				'id'		=> 'menu_icon',
				'title'		=> 'Menu icon url - $args[menu_icon]',
				'desc'		=> 'Optional - The url to the icon to be used for this menu.',
				'type'		=> 'text',
				'default'	=> '',
				'array_key'	=> 'args'
			);
			/**
			* END - Menu Options
			**/
			
			/**
			* Capability Options
			**/
			$output[] = array(
				'section' 	=> $this->get_slug('post_capability_options'),
				'id'		=> 'capability_type',
				'title'		=> 'Capability Type - $args[capability_type]',
				'desc'		=> 'Optional - The string to use to build the read, edit, and delete capabilities.',
				'type'		=> 'select',
				'default'	=> 'post',
				'choices'	=> array(
					'Post' => 'post',
					'Page' => 'page'
				),
				'array_key'	=> 'args'
			);
			/**
			* END - Capability Options
			**/
			
			/**
			* Advanced Options
			**/
			//Post Type has archive
			$output[] = array(
				'section' 	=> $this->get_slug('post_advanced_options'),
				'id'		=> 'has_archive',
				'title'		=> 'Has Archive Page - $args[has_archive]',
				'desc'		=> 'Optional - Enables post type archives. Will use $post_type as archive slug by default.',
				'type'		=> 'checkbox',
				'default'	=> '',
				'array_key'	=> 'args'
			);
			/**
			* END - Advanced Options
			**/
			
		// END FIELDS //
		
		
		if( !empty($output) ) {
			return $output;
		} else {
			return false;
		}
		
	}
	
	/**
	* Validate
	* 
	* Makes use of the pressoholics framework validation helper to validate/sanitize data
	* Also uses the flash helper to return a message to the user.
	*
	* HOW TO USE:
	*	You should only have to add the fields you wish to validate into the $validate array
	*
	*	Like this: 
	*	$validate[ $fb_url_slug ] = array( 'nice_name' => 'Facebook Page Url', 'type' => 'url', 'message' => 'Invalid URL.', 'empty' => true ,'regex' => null );
	*
	*	'type' tells the validation model how to validate the field e.g phone_us, email, url, password
	*	'empty'	NOT REQUIRED will tell the validator that you are happy to let this field be null
	*	'regex'	This will override the 'type' arg and the validator will use the regex provided to validate the field
	* 
	* @access 	public
	* @author	Ben Moody
	*/
	public function validate( $data ) {

		//Init required Pressoholics Helpers and Models
		global $PrsoFlash;
		global $PrsoValidate;
		
		//Init vars
		$validate = array(); //An array of fields to validate

		//First check to see if required Pressoholic framework plugin methods are installed
		if( is_object( $PrsoValidate ) && method_exists( $PrsoValidate, 'sanitize' ) && method_exists( $PrsoValidate, 'validate' ) ) {
		
			//Init vars
			$validate = array(); //Cache all fields to validate
			
			/***  Create an array of all fields you would like to validate  ***/
			
			//Box Title//
			//$title_slug = $this->get_slug('field_title_str');
			//$validate[ $fb_url_slug ] = array( 'nice_name' => 'Facebook Page Url', 'type' => 'url', 'message' => 'Invalid URL.', 'empty' => true ,'regex' => null );
			
			/*** END field array creation ***/
			
			//Call pressoholics validation helper and pass core data array and validation array
			$data = $PrsoValidate->validate( $data, $validate );
			
			//Detect validation errors in data look for error key
			if( isset( $data['error'] ) && $data['error'] ) {
				//Set main page flash message
				$PrsoFlash->set_flash( 'Some fields failed validation. See below for details.', 'error' );
			} else {
				//All is well :)
				$PrsoFlash->set_flash( 'Theme options saved.', 'success' );
			}
			
			return $data;
			
		} else {
			//Missing requried objects, so Pressoholics companion theme plugin not installed :(
			wp_die( __( 'Required plugin missing. Have you installed the Pressoholics Theme Plugin?' ) );		
		}
		
	}
	
	
	
	/**
	*
	* END - OPTIONS PAGE SETUP
	*
	*/
	
	/**
	* create_settings
	* 
	* Called in add action to create and output option form sections and fields
	* Makes use of Admin model class to create form field sections then populate those sections
	* with input fields.
	*
	* NOTE: Passes the results of setup_sections and set_fields to the Admin model classes. So setup your
	* 		sections and fields in setup_sections and set_fields methods.
	*
	*/
	public function create_settings() {
		//Register santization callback
		register_setting(
			$this->box_options_slug,
			$this->box_options_slug,
			array( &$this, 'validate' )
		);
		
		global $PrsoAdmin;
		//Setup sections
		$PrsoAdmin->load_sections( $this->setup_sections(), $this->box_options_slug );
		
		//Setup fields
		$PrsoAdmin->load_fields( $this->setup_fields(), $this->box_options_slug, $this->data );
	}
	
	/**
	* current_fields_table
	* 
	* Creates and returns the html required to output the Current Fields table.
	* Makes use of the Admin model class and it's table() helper to create the html for the table
	*
	* $args controlls the number and lable of each column via the 'headers' array. A caption string can be added if wished under 'caption'
	*
	* Pass data for each table row using the second param of table() helper. The row_data array should contain a new array for each row of the table.
	* Each row array should contain the relevant data required for each column in the same order as they are set in the $args['header'] array.
	*
	* EXAMPLE:
	*			ROW 1 - $row_data[0] => array( 0 => 'col_1_data', 1 => 'col_2_data', 2 => 'col_3_data' )
	*			ROW 2 - $row_data[1] => array( 0 => 'col_1_data', 1 => 'col_2_data', 2 => 'col_3_data' )
	*			ROW 3 - $row_data[2] => array( 0 => 'col_1_data', 1 => 'col_2_data', 2 => 'col_3_data' )
	*
	*/
	private function current_fields_table() {
		
		global $PrsoAdmin;
		
		//Init data vars
		$temp_data 	= array();
		$row_data	= array();
		
		//Init action vars
		$edit_url 	= null;
		$delete_url	= null;
		
		//var_dump( $this->data );
		
		//Set args for this table
		$args = array(
			'headers' => array(
				'Field',
				'Custom field key',
				'Type',
				'Actions'
			),
			'caption' => '<h3>Custom fields in this box:</h3>'
		);
		
		//Loop the box options data array if not empty and build table rows data
		if( !empty( $this->data[ $this->box_options_slug ]['fields'] ) && isset( $this->data['get']['post_key'] ) ) {
		
			$temp_data = $this->data[ $this->box_options_slug ]['fields'];
			
			$i = 0;
			foreach( $temp_data as $field_key => $field_data ) {
				
				//Check the field array is not empty
				if( !empty( $field_data ) && is_array( $field_data ) ) {
					
					//Cache the field title as the first $row_data array value as title is the first table column
					$row_data[$i][0] = ucfirst( $field_data[ $this->get_slug('field_title_str') ] );
					
					//Cache the field slug (key) as the second $row_data array value as slug is the second table column
					$row_data[$i][1] = $field_key;
					
					//Cache the field type as the third $row_data array value as type is tge thrid table column
					$row_data[$i][2] = $field_data[ $this->get_slug('field_type_str') ];
					
					//Now finally lets create the actions for this row - edit, delete
					$row_data[$i][3] = $PrsoAdmin->button( 'Edit', 
						array( 'page_slug' => $this->get_slug( 'plugin_index_page_slug' ), 'controller' => 'field', 'action' => 'edit', 'class' => 'button-primary', 'p_style' => 'float: left;', 'type' => null ),
						array( 'post_key' => $this->data['get']['post_key'], 'field_key' => $field_key )
					);
					
					$row_data[$i][3].= $PrsoAdmin->button( 'delete', 
						array( 'page_slug' => $this->get_slug( 'plugin_index_page_slug' ), 'controller' => 'field', 'action' => 'delete', 'class' => 'button-primary', 'type' => null, 'onclick' => "return confirm('Are you sure you want to delete this custom field?');" ),
						array( 'post_key' => $this->data['get']['post_key'], 'noheader' => 'true', 'field_key' => $field_key )
					);
					
					$i++;
				}
				
			}
			
		}
		
		//Call PrsoAdmin table helper to output admin table
		return $PrsoAdmin->table( $args, $row_data );
		
	}
	
	public function save_post() {
		
		//Init vars
		$post_key 	= null;
		$url		= null;
		
		//Check for form submission
		if( isset( $_POST[ $this->box_options_slug ] ) ){
			
			$clean_data = $this->validate( $_POST[$this->box_options_slug] );
			
			var_dump($clean_data);
			exit();
			
			//ON ADD - create a unique key for each new post type created
			if( !isset($this->data['get']['post_key']) ){
				$field_title_slug = $this->get_slug( 'field_title_str' );
				if( isset($clean_data[ $field_title_slug ]) ) {
					$post_key = strtolower( $clean_data[ $field_title_slug ] );
					$post_key = str_replace( ' ', '_', $post_key );
				}
			} else {
				$post_key = $this->data['get']['post_key'];
			}
			
			//Get current plugin options data
			$this->get_options( $this->box_options_slug );
			
			//ON EDIT - Unset current data from options array - avoid duplication
			if( isset($this->data['get']['post_key']) ) {
				$clean_data = wp_parse_args( $clean_data, $this->data[$this->box_options_slug][$this->data['get']['post_key']] );
				unset( $this->data[$this->box_options_slug][ $this->data['get']['post_key'] ] );
			}
			
			//Add new data array to current box data in options
			$this->data[$this->box_options_slug][$post_key] = $clean_data;
			
			//Save options array
			update_option( $this->box_options_slug, $this->data[$this->box_options_slug] );
			
		}
		
		//Redirect to the fields plugin home
		$this->plugin_redirect();
	}
	
}