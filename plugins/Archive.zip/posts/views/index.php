<?php
/**
* Pressoholics Fields Pluign View.
*
*/

class PrsoPostsViewIndex extends PrsoPostsFunctions {
	
	protected function index( $get_data = array() ) {
		
		//Set box data array key
		$this->box_options_slug = $this->get_slug( 'box_options_slug' );;
		
		//Cache get_data
		$this->data['get'] = $get_data;
		
		//Init box options data array
		$this->data[ $this->box_options_slug ] = array();
		
		//Call method to get box options data for database
		$this->get_options( $this->box_options_slug );
		
		//Start view output
		$this->start_option_page();
		
	}
	
	/**
	* start_option_page
	* 
	* Used by wp function add_menu_page to create and parse the admin options page
	* 
	* @access 	public
	* @author	Ben Moody
	*/
	private function start_option_page() {
		global $PrsoAdmin;
		
		?>
		<div class="wrap">
			<?php screen_icon( 'options-general' ); ?>
			<h2><?php echo $this->plugin_index_page_title; ?></h2>
			
			<!-- display developer data such as options id slug !-->
			<p>
				<a href="#" class="button-primary" onclick="jQuery('#dev-info').show('slide');return false;" >Dev Info</a>
			</p>
			
			<div id="dev-info" style="display:none;">
			<ul>
				<li>Options Slug: <?php echo $this->box_options_slug; ?></li>
			</ul>
			</div>
			
			<!-- Output jquery to active field validation messages !-->
			<?php 
				global $PrsoFlash;
				echo $PrsoFlash->get_validate_flash(); 
			?>
			
			<p>Listed below are the boxes that were created in Pressoholics Fields. These boxes appear on the Write/Edit page.</p>
			<p>Click on the name of a box to edit and add fields</p>
		
		<?php
		
		//Output table of current custom fields
		//echo $this->current_fields_table();
		
		//Create an action button that links to controller => box, action => add
		echo $PrsoAdmin->button( 'New custom post type', array( 'page_slug' => $this->get_slug( 'plugin_index_page_slug' ), 'controller' => 'post', 'action' => 'add', 'class' => 'button-primary', 'type' => null ) );
		
	}
	
	/**
	* current_fields_table
	* 
	* Creates and returns the html required to output the Current Fields table.
	* Makes use of the Admin model class and it's table() helper to create the html for the table
	*
	* $args controlls the number and lable of each column via the 'headers' array. A caption string can be added if wished under 'caption'
	*
	* Pass data for each table row using the second param of table() helper. The row_data array should contain a new array for each row of the table.
	* Each row array should contain the relevant data required for each column in the same order as they are set in the $args['header'] array.
	*
	* EXAMPLE:
	*			ROW 1 - $row_data[0] => array( 0 => 'col_1_data', 1 => 'col_2_data', 2 => 'col_3_data' )
	*			ROW 2 - $row_data[1] => array( 0 => 'col_1_data', 1 => 'col_2_data', 2 => 'col_3_data' )
	*			ROW 3 - $row_data[2] => array( 0 => 'col_1_data', 1 => 'col_2_data', 2 => 'col_3_data' )
	*
	*/
	private function current_fields_table() {
		
		global $PrsoAdmin;
		
		//Init data vars
		$temp_data 	= array();
		$row_data	= array();
		$box_data	= array();
		
		//Init action vars
		$edit_url 	= null;
		$delete_url	= null;
		
		//var_dump( $this->data );
		
		//Set args for this table
		$args = array(
			'headers' => array(
				'Box',
				'Nbr of fields',
				'Actions'
			),
			'caption' => '<h3>Meta Fields Boxes</h3>'
		);
		
		//Loop the box options data array if not empty and build table rows data
		if( !empty( $this->data[ $this->box_options_slug ] ) ) {
		
			$temp_data = $this->data[ $this->box_options_slug ];
			
			$i = 0;
			foreach( $temp_data as $box_key => $fields ) {
				
				//Check the key is a string and the fields var is an array
				if( !empty( $box_key ) && is_string( $box_key ) ) {

					if( !empty( $fields ) && is_array( $fields ) ) {
						
						//Loop the fields array cache box title in table data array
						foreach( $fields as $field_slug => $field_val ) {
							//Get field containing box title - first row so array key = 0
							if( preg_match( '(_title_)', $field_slug ) ) {
								$row_data[$i][0] = ucfirst($field_val);
							}
						}
						
						//Get fields associated with this box from database
						$box_data = $temp_data[ $box_key ];
						
						//Cache the number of fields returned in table data array as second column key = 1
						$no_rows = 0;
						if( !empty($box_data) && isset($box_data['fields']) ) {
							$no_rows = count( $box_data['fields'] );
						}
						//Cache field count
						$row_data[$i][1] = $no_rows;
						
						//Now finally lets create the actions for this row - edit, delete
						$row_data[$i][2] = $PrsoAdmin->button( 'Edit', 
							array( 'page_slug' => $this->get_slug( 'plugin_index_page_slug' ), 'controller' => 'box', 'action' => 'edit', 'class' => 'button-primary', 'p_style' => 'float: left;', 'type' => null ),
							array( 'box_key' => $box_key )
						);
						
						$row_data[$i][2].= $PrsoAdmin->button( 'delete', 
							array( 'page_slug' => $this->get_slug( 'plugin_index_page_slug' ), 'controller' => 'box', 'action' => 'delete', 'class' => 'button-primary', 'type' => null, 'onclick' => "return confirm('Are you sure you want to delete this box?');" ),
							array( 'box_key' => $box_key, 'noheader' => 'true' )
						);
						
						$i++;
					}
					
				}
				
			}
			
		}
		
		//Call PrsoAdmin table helper to output admin table
		return $PrsoAdmin->table( $args, $row_data );
		
	}
	
}