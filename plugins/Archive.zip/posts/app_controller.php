<?php
/**
 * Common App Functions
 *
 * Contains common methods used in many pressoholics plugins
 *
 * Use the Wordpress API call's within __construct to call your methods:
 *	//Action hook example
 *	add_action( 'init', array( &$this, 'test' ) ); 
 *
 * Contents:
 * 
 *
 */
class PrsoPostsAppController {
	
	// <!-------  PLUGIN OPTIONS ---------!>
	
	//Set all constants for this plugin
	protected $plugin_parent_page_slug = 'prso_plugin_admin_main'; 	//FULL Page slug of plugin parent - INCLUDE prso unique prepend
	protected $plugin_index_page_slug	= 'admin_page'; 				//Short slug used to identify the plugin's index page - DONT add the prso unique prepend
	protected $plugin_index_page_title	= 'Pressoholics Custom Post Types';	//Title to display for this plugin
	
	//Settings for plugins options data
	protected $box_options_slug = 'custom_posts'; //The unique slug used to identify this plugin - also used to store and indentify plugin option data
	
	//Cache constants for use throughout the plugin - YOU WILL HAVE TO UPDATE THIS FOR EACH NEW PLUGIN, see config.php
	protected $plugin_slug 		= PRSO_POSTS_SLUG;
	protected $plugin_root		= PRSO_POSTS_ROOT;
	protected $plugin_views		= PRSO_POSTS_VIEWS;
	protected $plugin_includes	= PRSO_POSTS_INCLUDES;
	protected $plugin_config	= PRSO_POSTS_CONFIG;
	protected $view_class_slug	= 'PrsoPostsView'; //Prefix used to name each view class for each plugin options page - e.g. Class PrsoPostsViewIndex extends PrsoPostsFunctions
	
	
	// <!-------  END PLUGIN OPTIONS ---------!>
	
	
	protected $data = null; //Master store of all data for plugin actions - options data, _GET, Overload data from magic methods
	
	/**
	* get_options
	* 
	* Little helper to get data from the wordpress options database table
	* and cache it for later use.
	* 
	* @access 	protected
	* @author	Ben Moody
	*/
	protected function get_options( $option_slug = null, $multi_array_slug = null ) {
		
		//Init vars
		$temp_data = array();
		
		//Get options from database using slug provided
		$temp_data = get_option( $option_slug );
		
		//if an multi array of data then use multi array slug as key
		if( isset( $multi_array_slug ) && array_key_exists( $multi_array_slug, $temp_data ) ) {
			$this->data[ $option_slug ] = $temp_data[ $multi_array_slug ];
		} else {
			$this->data[ $option_slug ] = $temp_data;
		}
		
		unset( $temp_data );
		
	}
	
	/**
	* get_slug
	* 
	* Little helper to prepend any slug vars with the framework slug constant PRSO_SLUG
	* helps to avoid any name conflicts with options slugs
	* 
	* @access 	protected
	* @author	Ben Moody
	*/
 	protected function get_slug( $var = null ) {
 		
 		if( isset( $this->$var ) ) {
 			return $this->plugin_slug . $this->$var;
 		} elseif( !empty($var) && is_string($var) ) {
 			//Return a new version of $var with prso slug appended
 			return $this->plugin_slug . $var;
 		} else {
 			//Error return null
 			return null;
 		}
 		
 	}
 	
 	/**
	* Request Router
	*
	* Detects any plugin specific controller and action requested in the admin url
	* finds the action and calls the specific method passing any params.
	* 
	*
	*/
	public function request_router( $plugin_slug = null ) {
		
		//Init vars
		$controller_key 		= 'controller';
		$action_key				= 'action';
		$data					= $_GET;
		
		if( isset($this->plugin_index_page_slug) ) {
			$plugin_slug = $this->plugin_index_page_slug;
		}
		
		//First check to see if a controller and action has been provided
		if( array_key_exists('controller', $data) && array_key_exists('action', $data) ) {
			
			//Run a nonce check on the get data
			$page_slug 		= $this->get_slug( $plugin_slug );
			$action			= $data['action'];
			$controller		= $data['controller'];
			$nonce_action 	= "{$page_slug}-{$action}_{$controller}";
			$nonce			= $_REQUEST['_wpnonce'];

			check_admin_referer( $nonce_action );
			
			//Call action to find and load appropriate view
			if( !$this->load_view( $data['controller'], $data['action'], $data ) ) {
				//Critical error
				wp_die( __( "There was an error while trying to load the plugin index controller." ) );
			}
		} else {
			//Call action to build plugin index page
			if( !$this->load_view() ) {
				//Critical error
				wp_die( __( "There was an error while trying to load the plugin index controller." ) );
			}
		}
		
	}
	
	/**
	* load_view
	*
	* Finds a views controller file, creates and instance of the class, and triggers the action method
	* Returns false on error.
	*
	*/
	private function load_view( $controller = 'index', $action = 'index', $data = null ) {
		
		//Init vars
		$view_class_slug 	= $this->view_class_slug;
		$controller			= strtolower( $controller );
		$result				= false;
		
		//If controller is null then just load index view
		
		//Find user function class and create instance
		if( file_exists( $this->plugin_views . "/{$controller}.php" ) ) {
		
			//Include view file
			include( $this->plugin_views . "/{$controller}.php" );
			
			//Instantiate class
			$view_class_slug = $view_class_slug . ucfirst( $controller );
			if( class_exists( $view_class_slug ) ) {
				$$view_class_slug = new $view_class_slug($data);
				
				//Load action
				if( method_exists( $$view_class_slug, $action ) ) {
					$$view_class_slug->$action();
					$result = true;
				}
			}
			
		}
		
		return $result;
	}
	
	//Magic methods set and get
	public function __set( $name, $value ) {
		
		if( isset($this->data) ) {
			$this->data[$name] = $value;
		}
		
	}
	
	public function __get( $name ) {
	
		if( isset($this->data) && array_key_exists( $name, $this->data ) ) {
			
			return $this->data[$name];
		
		}
		
		return null;
	}
	
	/**
	* form_action
	*
	* Creates a form action url based on the $controller and $action params provided.
	* The method will also create a Nonce based on page_slug-action-controller and append it
	* to the url using add_query_arg
	*
	*/
	protected function form_action( $action = null ) {
		
		//Build the form action url
		$controller = $this->data['get']['controller'];
		$page_slug	= $this->get_slug( 'plugin_index_page_slug' );
		
		$url = add_query_arg( array( 'controller' => $controller, 'action' => $action, 'noheader' => 'true', '_wpnonce' => false ) );
		
		//Add a Nonce to the url
		$nonce_action = "{$page_slug}-{$action}_{$controller}";
		
		$url = wp_nonce_url( $url, $nonce_action );
		
		return $url;
	}
	
	protected function plugin_redirect( $meta_redirect = false, $args = array() ) {
		
		//Init vars
		$url = null;
		$defaults = array(
			'plugin_slug' 	=> $this->get_slug( 'plugin_index_page_slug' ),
			'controller'	=> '',
			'action'		=> '',
			'params'		=> array()
		);
		
		$args = wp_parse_args( $args, $defaults );
		extract( $args );

		if( $meta_redirect ) {

			$url = admin_url() . 'admin.php?page='. $plugin_slug . '&controller=' . $controller . '&action=' . $action;
			
			//Loop extra params and add them to the end of the url
			if( !empty($params) && is_array($params) ) {
				foreach( $params as $key => $val ) {
					$url.= "&{$key}={$val}";
				}
			}

			//Add a Nonce to the url
			$nonce_action = "{$plugin_slug}-{$action}_{$controller}";
	
			$url = wp_nonce_url( $url, $nonce_action );
			
			echo "<meta http-equiv='refresh' content='0; url={$url}'>";
			exit;
		
		} else {
			
			//Redirect to the fields plugin home
			$plugin_slug	= $this->get_slug( 'plugin_index_page_slug' );
			$url 			= add_query_arg( array( 'page' => $plugin_slug ), admin_url() . 'admin.php' );
	
			wp_redirect( $url );
			exit;
			
		}
		
	}

}