<?php
/**
 * General App Functions
 *
 * Usually contains general functions required to get the plugin started such as request_router
 *
 * Use the Wordpress API call's within __construct to call your methods:
 *	//Action hook example
 *	add_action( 'init', array( &$this, 'test' ) ); 
 *
 * Contents:
 * 
 *
 */
class PrsoPostsFunctions extends PrsoPostsAppController {
	
	function __construct() {
 		//Boot plugin
 		$this->boot();
	}
	
	public function boot() {
		
		//Run admin_init actions
		add_action( 'admin_init', array(&$this, 'admin_init') );
		
		//Add admin menu items
		add_action('admin_menu', array( &$this, 'add_admin_menu_pages' ));
		
	}
	
	public function add_admin_menu_pages() {
		//Add child options page to presso theme plugin
		add_submenu_page(
			$this->plugin_parent_page_slug,
			$this->plugin_index_page_title,
			'Posts',
			'administrator',
			$this->get_slug( 'plugin_index_page_slug' ),
			array( &$this, 'request_router' )
		);
	}
	
	public function admin_init() {
		
		//Enqueue plugin scripts/styles
		$this->enqueue_scripts();
		
		//Add filters
		$this->add_filters();
		
	}
	
	private function enqueue_scripts() {
		

	}
	
	private function add_filters() {
		
	}
	
	

}