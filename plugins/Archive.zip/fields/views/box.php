<?php
/**
* Pressoholics Fields Pluign View.
*
* Handles requests for custom fields boxes.
*
*/

class PrsoFieldsViewBox extends PrsoFieldsFunctions {
	
	private	$box_key	= null; //Cache the unique option data array key for current field box
	
	function __construct( $get_data = array() ) {
		
		//Set view title
		$this->box_options_slug = $this->get_slug( 'box_options_slug' );
		
		//Cache get data
		$this->data['get'] = $get_data;
		
		//Init database array in class $data var
		$this->data[ $this->box_options_slug ] = array();
		
		//If this is an edit action get the box_key and use as data array key
		if( isset($this->data['get']['action']) && $this->data['get']['action'] === 'edit' ) {		
			if( isset($this->data['get']['box_key']) ) {
				//Cache key
				$this->box_key = $this->data['get']['box_key'];
				
				//Get page options from database and store for later
				$this->get_options( $this->box_options_slug, $this->box_key );
			}
		}
		
		//If this is an delete action get the box_key and get all option data for this controller
		if( isset($this->data['get']['action']) && $this->data['get']['action'] === 'delete' ) {		
			if( isset($this->data['get']['box_key']) ) {
				//Cache key
				$this->box_key = $this->data['get']['box_key'];
				
				//Get page options from database and store for later
				$this->get_options( $this->box_options_slug );
			}
		}		
		
	}
	
	public function add() {
	
		//Init helper classes
		global $PrsoAdmin;
		global $PrsoFlash;
		
		//Call method to create form settings
		$this->create_settings();
		
		?>
		<div class="wrap">
			<?php screen_icon( 'options-general' ); ?>
			<h2><?php echo $this->plugin_index_page_title; ?></h2>
			
			<!-- Output jquery to active field validation messages !-->
			<?php 
				echo $PrsoFlash->get_validate_flash(); 
			?>
			
			<?php
			//Output table of current custom fields
			echo $this->current_fields_table();
			//Create an action button that links to controller => box, action => add
			echo $PrsoAdmin->button( 'New field', array( 'page_slug' => $this->get_slug( 'plugin_index_page_slug' ), 'controller' => 'field', 'action' => 'add', 'class' => 'button-primary', 'type' => null ) );
			?>
			
		</div>
		
		<div class="wrap">
			<form action="<?php echo $this->form_action( 'save_box' ); ?>" method="post">
				
				<!-- Form sections !-->
				<?php do_settings_sections( $this->box_options_slug ); ?>
				
				<p class="submit">
					<input class="button-primary" name="Submit" type="submit" value="Save Changes" />
				</p>
			</form>
		</div>
		<?php
		
	}
	
	public function edit() {
		
		//Carryout any specific edit functions then call add action
		$this->add();
		
	}
	
	public function delete() {
		
		global $PrsoFlash;
		
		//Set default flash message
		$PrsoFlash->set_flash( 'There was a problem deleting the box.', 'error' );
		
		//Check that the box key isset
		if( !empty($this->box_key) ) {
			
			//Confirm user can delete posts
			if( current_user_can( 'administrator' ) ) {
				
				//Now check that the options data array is not empty
				if( !empty( $this->data[$this->box_options_slug] ) && is_array( $this->data[$this->box_options_slug] ) ) {
				
					//Finally unset box_key data from options data array
					if( array_key_exists( $this->box_key, $this->data[$this->box_options_slug] ) ) {
						unset( $this->data[$this->box_options_slug][$this->box_key] );
						
						//Now update the options data
						update_option( $this->box_options_slug, $this->data[$this->box_options_slug] );
						
						//Set flash message
						$PrsoFlash->set_flash( 'Fields Box Deleted.', 'success' );
					}
				
				}
				
			}
			
		}
		
		//Redirect to the fields plugin home
		$this->plugin_redirect();
	}
	
	/**
	* setup_sections
	* 
	* Add section options array to $output to create a new section
	*
	* See the commented example within function.
	* 
	* @access 	private
	* @author	Ben Moody
	*/
	private function setup_sections() {
		
		//Init vars
		$output = array(); //Cache all sections setup arrays
		
		/*
		$output[] = array(
			'id' 		=> $this->get_slug('general_options'),
			'title'		=> ''
		);
		*/
		
		// ADD YOUR SECTIONS HERE //
		
		//General options section
		$output[] = array(
			'id' 	=> $this->get_slug('box_options'),
			'title'	=> 'General Options'
		);
		$output[] = array(
			'id' 	=> $this->get_slug('box_advanced_options'),
			'title'	=> 'Advanced Options'
		);
		
		// END SECTIONS //
		
		if( !empty($output) ) {
			return $output;
		} else {
			return false;
		}
		
	}
	
	/**
	* setup_fields
	* 
	* Add field options array to $output to create a new section field
	*
	* See the commented example within function.
	*
	* 'type' is required as this is used by the admin model (in presso plugin) to decide how to output the form element html.
	* 
	* 	'type' Options: text, textarea, select, checkbox
	* 
	* @access 	private
	* @author	Ben Moody
	*/
	private function setup_fields() {
		
		//Init vars
		$output = array(); //Cache all sections setup arrays
		
		/*
		$output[] = array(
			'section' 	=> $this->get_slug('general_options'),
			'id'		=> $this->get_slug('field_legal_html'),
			'title'		=> '',
			'desc'		=> '',
			'type'		=> '',
			'default'	=> ''
		);
		*/
		
		
		// ADD YOUR FIELDS HERE //
		
			// **General Options Section
			$output[] = array(
				'section' 	=> $this->get_slug('box_options'),
				'id'		=> $this->get_slug('field_title_str'),
				'title'		=> 'Title of the box',
				'desc'		=> 'This is the title that will appear at the top of the field section box.',
				'type'		=> 'text',
				'default'	=> ''
			);
			
			//Create multi-checkbox of all registered post types//
			$post_types = get_post_types();
			// Ignore post type we have no interest in
			$remove = array('attachment', 'revision', 'nav_menu_item');
			//Loop post types array and create the array required to output multi-checkboxes using load_fields helper
			$post_type_choices = array();
			if( !empty($post_types) ) {
				foreach( $post_types as $type_slug ) {
					//Check for post types to remove
					if( !in_array( $type_slug, $remove ) ) {
						$post_name = ucfirst( str_replace( '_', ' ', $type_slug ) );
						$post_type_choices[$post_name] = $this->get_slug($type_slug . '_int');
					}
				}
			}
			$output[] = array(
				'section' 	=> $this->get_slug('box_options'),
				'id'		=> $this->get_slug('box_post_types'),
				'title'		=> 'Used with these post types',
				'desc'		=> 'Select the post types where this box should appear',
				'type'		=> 'multi-checkbox',
				'default'	=> '',
				'choices'	=> $post_type_choices
			);
			//END post types multi checkboxes//
			
			// **Advanced Options Section
			$output[] = array(
				'section' 	=> $this->get_slug('box_advanced_options'),
				'id'		=> $this->get_slug('box_position_str'),
				'title'		=> 'Field box position',
				'desc'		=> 'Position of field box in post edit screen',
				'type'		=> 'radio',
				'default'	=> array( 'left' => 'left' ),
				'choices'	=> array( 'Left' => 'left', 'Right' => 'right' )
			);
			
			//Create multi-checkbox of all registered user roles//
	        global $wp_roles;
	       	$roles = $wp_roles->get_names();
	 		//Loop roles array and create the array required to output multi-checkboxes using load_fields helper
	 		$role_type_choices = array();
	 		if( !empty($roles) ) {
				foreach( $roles as $slug => $role_name ) {
					$role_type_choices[$role_name] = $this->get_slug($slug . '_int');
				}
			}
	 		$output[] = array(
				'section' 	=> $this->get_slug('box_advanced_options'),
				'id'		=> $this->get_slug('box_user_roles'),
				'title'		=> 'User role access',
				'desc'		=> 'Select the user roles who can use this fields box',
				'type'		=> 'multi-checkbox',
				'default'	=> '',
				'choices'	=> $role_type_choices
			);
		// END FIELDS //
		
		
		if( !empty($output) ) {
			return $output;
		} else {
			return false;
		}
		
	}
	
	/**
	* Validate
	* 
	* Makes use of the pressoholics framework validation helper to validate/sanitize data
	* Also uses the flash helper to return a message to the user.
	*
	* HOW TO USE:
	*	You should only have to add the fields you wish to validate into the $validate array
	*
	*	Like this: 
	*	$validate[ $fb_url_slug ] = array( 'nice_name' => 'Facebook Page Url', 'type' => 'url', 'message' => 'Invalid URL.', 'empty' => true ,'regex' => null );
	*
	*	'type' tells the validation model how to validate the field e.g phone_us, email, url, password
	*	'empty'	NOT REQUIRED will tell the validator that you are happy to let this field be null
	*	'regex'	This will override the 'type' arg and the validator will use the regex provided to validate the field
	* 
	* @access 	public
	* @author	Ben Moody
	*/
	public function validate( $data ) {

		//Init required Pressoholics Helpers and Models
		global $PrsoFlash;
		global $PrsoValidate;
		
		//Init vars
		$validate = array(); //An array of fields to validate

		//First check to see if required Pressoholic framework plugin methods are installed
		if( is_object( $PrsoValidate ) && method_exists( $PrsoValidate, 'sanitize' ) && method_exists( $PrsoValidate, 'validate' ) ) {
		
			//Init vars
			$validate = array(); //Cache all fields to validate
			
			/***  Create an array of all fields you would like to validate  ***/
			
			//Box Title//
			//$title_slug = $this->get_slug('field_title_str');
			//$validate[ $fb_url_slug ] = array( 'nice_name' => 'Facebook Page Url', 'type' => 'url', 'message' => 'Invalid URL.', 'empty' => true ,'regex' => null );
			
			/*** END field array creation ***/
			
			//Call pressoholics validation helper and pass core data array and validation array
			$data = $PrsoValidate->validate( $data, $validate );
			
			//Detect validation errors in data look for error key
			if( isset( $data['error'] ) && $data['error'] ) {
				//Set main page flash message
				$PrsoFlash->set_flash( 'Some fields failed validation. See below for details.', 'error' );
			} else {
				//All is well :)
				$PrsoFlash->set_flash( 'Theme options saved.', 'success' );
			}
			
			return $data;
			
		} else {
			//Missing requried objects, so Pressoholics companion theme plugin not installed :(
			wp_die( __( 'Required plugin missing. Have you installed the Pressoholics Theme Plugin?' ) );		
		}
		
	}
	
	
	
	/**
	*
	* END - OPTIONS PAGE SETUP
	*
	*/
	
	/**
	* create_settings
	* 
	* Called in add action to create and output option form sections and fields
	* Makes use of Admin model class to create form field sections then populate those sections
	* with input fields.
	*
	* NOTE: Passes the results of setup_sections and set_fields to the Admin model classes. So setup your
	* 		sections and fields in setup_sections and set_fields methods.
	*
	*/
	public function create_settings() {
		//Register santization callback
		register_setting(
			$this->box_options_slug,
			$this->box_options_slug,
			array( &$this, 'validate' )
		);
		
		global $PrsoAdmin;
		//Setup sections
		$PrsoAdmin->load_sections( $this->setup_sections(), $this->box_options_slug );
		
		//Setup fields
		$PrsoAdmin->load_fields( $this->setup_fields(), $this->box_options_slug, $this->data );
	}
	
	/**
	* current_fields_table
	* 
	* Creates and returns the html required to output the Current Fields table.
	* Makes use of the Admin model class and it's table() helper to create the html for the table
	*
	* $args controlls the number and lable of each column via the 'headers' array. A caption string can be added if wished under 'caption'
	*
	* Pass data for each table row using the second param of table() helper. The row_data array should contain a new array for each row of the table.
	* Each row array should contain the relevant data required for each column in the same order as they are set in the $args['header'] array.
	*
	* EXAMPLE:
	*			ROW 1 - $row_data[0] => array( 0 => 'col_1_data', 1 => 'col_2_data', 2 => 'col_3_data' )
	*			ROW 2 - $row_data[1] => array( 0 => 'col_1_data', 1 => 'col_2_data', 2 => 'col_3_data' )
	*			ROW 3 - $row_data[2] => array( 0 => 'col_1_data', 1 => 'col_2_data', 2 => 'col_3_data' )
	*
	*/
	private function current_fields_table() {
		
		global $PrsoAdmin;
		
		//Init data vars
		$temp_data 	= array();
		$row_data	= array();
		
		//Init action vars
		$edit_url 	= null;
		$delete_url	= null;
		
		//var_dump( $this->data );
		
		//Set args for this table
		$args = array(
			'headers' => array(
				'Field',
				'Custom field key',
				'Type',
				'Actions'
			),
			'caption' => '<h3>Custom fields in this box:</h3>'
		);
		
		//Loop the box options data array if not empty and build table rows data
		if( !empty( $this->data[ $this->box_options_slug ]['fields'] ) && isset( $this->data['get']['box_key'] ) ) {
		
			$temp_data = $this->data[ $this->box_options_slug ]['fields'];
			
			$i = 0;
			foreach( $temp_data as $field_key => $field_data ) {
				
				//Check the field array is not empty
				if( !empty( $field_data ) && is_array( $field_data ) ) {
					
					//Cache the field title as the first $row_data array value as title is the first table column
					$row_data[$i][0] = ucfirst( $field_data[ $this->get_slug('field_title_str') ] );
					
					//Cache the field slug (key) as the second $row_data array value as slug is the second table column
					$row_data[$i][1] = $field_key;
					
					//Cache the field type as the third $row_data array value as type is tge thrid table column
					$row_data[$i][2] = $field_data[ $this->get_slug('field_type_str') ];
					
					//Now finally lets create the actions for this row - edit, delete
					$row_data[$i][3] = $PrsoAdmin->button( 'Edit', 
						array( 'page_slug' => $this->get_slug( 'plugin_index_page_slug' ), 'controller' => 'field', 'action' => 'edit', 'class' => 'button-primary', 'p_style' => 'float: left;', 'type' => null ),
						array( 'box_key' => $this->data['get']['box_key'], 'field_key' => $field_key )
					);
					
					$row_data[$i][3].= $PrsoAdmin->button( 'delete', 
						array( 'page_slug' => $this->get_slug( 'plugin_index_page_slug' ), 'controller' => 'field', 'action' => 'delete', 'class' => 'button-primary', 'type' => null, 'onclick' => "return confirm('Are you sure you want to delete this custom field?');" ),
						array( 'box_key' => $this->data['get']['box_key'], 'noheader' => 'true', 'field_key' => $field_key )
					);
					
					$i++;
				}
				
			}
			
		}
		
		//Call PrsoAdmin table helper to output admin table
		return $PrsoAdmin->table( $args, $row_data );
		
	}
	
	public function save_box() {
		
		//Init vars
		$box_key 	= null;
		$url		= null;
		
		//Check for form submission
		if( isset( $_POST[ $this->box_options_slug ] ) ){
			
			$clean_data = $this->validate( $_POST[$this->box_options_slug] );
			
			//ON ADD - create a unique key for each new box created
			if( !isset($this->data['get']['box_key']) ){
				$field_title_slug = $this->get_slug( 'field_title_str' );
				if( isset($clean_data[ $field_title_slug ]) ) {
					$box_key = strtolower( $clean_data[ $field_title_slug ] );
					$box_key = str_replace( ' ', '_', $box_key );
				}
			} else {
				$box_key = $this->data['get']['box_key'];
			}
			
			//Get current plugin options data
			$this->get_options( $this->box_options_slug );
			
			//ON EDIT - Unset current data from options array - avoid duplication
			if( isset($this->data['get']['box_key']) ) {
				$clean_data = wp_parse_args( $clean_data, $this->data[$this->box_options_slug][$this->data['get']['box_key']] );
				unset( $this->data[$this->box_options_slug][ $this->data['get']['box_key'] ] );
			}
			
			//Add new data array to current box data in options
			$this->data[$this->box_options_slug][$box_key] = $clean_data;
			
			//Save options array
			update_option( $this->box_options_slug, $this->data[$this->box_options_slug] );
			
		}
		
		//Redirect to the fields plugin home
		$this->plugin_redirect();
	}
	
}