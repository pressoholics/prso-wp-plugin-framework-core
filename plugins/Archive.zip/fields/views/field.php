<?php
/**
* Pressoholics Fields Pluign View.
*
* Handles requests for creating custom fields.
*
*/

class PrsoFieldsViewField extends PrsoFieldsFunctions {
	
	private	$box_key	= null; //Cache the unique option data array key for current field box
	private	$field_key	= null; //Cache the unique option data array key for current field data array
	
	function __construct( $get_data = array() ) {
		
		//Set view title
		$this->box_options_slug = $this->get_slug( 'box_options_slug' );
		
		//Cache get data
		$this->data['get'] = $get_data;
		
		//Init database array in class $data var
		$this->data[ $this->box_options_slug ] = array();
		
		//If this is an edit action get the box_key and use as data array key
		if( isset($this->data['get']['action']) && $this->data['get']['action'] === 'edit' ) {		
			if( isset($this->data['get']['box_key']) ) {
				//Cache key
				$this->box_key = $this->data['get']['box_key'];
				
				//Get page options from database and store for later
				$this->get_options( $this->box_options_slug, $this->box_key );
			}
		}
		
		//If this is an delete action get the box_key and get all option data for this controller
		if( isset($this->data['get']['action']) && $this->data['get']['action'] === 'delete' ) {		
			if( isset($this->data['get']['box_key']) && isset($this->data['get']['field_key']) ) {
				//Cache key
				$this->box_key 		= $this->data['get']['box_key'];
				$this->field_key	= $this->data['get']['field_key'];
				
				//Get page options from database and store for later
				$this->get_options( $this->box_options_slug );
			}
		}		
		
	}
	
	public function add() {
	
		//Init helper classes
		global $PrsoAdmin;
		global $PrsoFlash;
		
		//Call method to create form settings
		$this->create_settings();
		
		?>	
		<div class="wrap">
			
			<?php screen_icon( 'options-general' ); ?>
			<h2><?php echo $this->plugin_index_page_title; ?></h2>
			
			<!-- Output jquery to active field validation messages !-->
			<?php 
				echo $PrsoFlash->get_validate_flash(); 
			?>
			
			<form action="<?php echo $this->form_action( 'save_field' ); ?>" method="post">
				
				<!-- Form sections !-->
				<?php do_settings_sections( $this->box_options_slug ); ?>
				
				<p class="submit">
					<input class="button-primary" name="Submit" type="submit" value="Save Changes" />
				</p>
			</form>
		</div>
		<?php
		
	}
	
	public function edit() {
		
		//Carryout any specific edit functions then call add action
		$this->add();
		
	}
	
	public function delete() {
		
		global $PrsoFlash;
		
		//Set default flash message
		$PrsoFlash->set_flash( 'There was a problem deleting the box.', 'error' );
		
		//Check that the box key isset
		if( !empty($this->box_key) && !empty($this->field_key) ) {
			
			//Confirm user can delete posts
			if( current_user_can( 'administrator' ) ) {
				
				//Now check that the options data array is not empty
				if( !empty( $this->data[$this->box_options_slug] ) && is_array( $this->data[$this->box_options_slug] ) ) {
				
					//Finally unset field_key data from options data array
					if( array_key_exists( $this->box_key, $this->data[$this->box_options_slug] ) ) {
						
						if( array_key_exists( $this->field_key, $this->data[$this->box_options_slug][$this->box_key]['fields'] ) ){
							unset( $this->data[$this->box_options_slug][$this->box_key]['fields'][$this->field_key] );
							
							//Now update the options data
							update_option( $this->box_options_slug, $this->data[$this->box_options_slug] );
							
							//Set flash message
							$PrsoFlash->set_flash( 'Fields Box Deleted.', 'success' );
						}
						
					}
				
				}
				
			}
			
		}
		
		//Redirect to the fields plugin home
		$this->plugin_redirect();
	}
	
	/**
	* setup_sections
	* 
	* Add section options array to $output to create a new section
	*
	* See the commented example within function.
	* 
	* @access 	private
	* @author	Ben Moody
	*/
	private function setup_sections() {
		
		//Init vars
		$output = array(); //Cache all sections setup arrays
		
		/*
		$output[] = array(
			'id' 		=> $this->get_slug('general_options'),
			'title'		=> ''
		);
		*/
		
		// ADD YOUR SECTIONS HERE //
		
		//General options section
		$output[] = array(
			'id' 	=> $this->get_slug('field_options'),
			'title'	=> 'General Options'
		);
		$output[] = array(
			'id' 	=> $this->get_slug('field_advanced_options'),
			'title'	=> 'Advanced Options'
		);
		
		// END SECTIONS //
		
		if( !empty($output) ) {
			return $output;
		} else {
			return false;
		}
		
	}
	
	/**
	* setup_fields
	* 
	* Add field options array to $output to create a new section field
	*
	* See the commented example within function.
	*
	* 'type' is required as this is used by the admin model (in presso plugin) to decide how to output the form element html.
	* 
	* 	'type' Options: text, textarea, select, checkbox
	* 
	* @access 	private
	* @author	Ben Moody
	*/
	private function setup_fields() {
		
		//Init vars
		$output = array(); //Cache all sections setup arrays
		
		/*
		$output[] = array(
			'section' 	=> $this->get_slug('general_options'),
			'id'		=> $this->get_slug('field_legal_html'),
			'title'		=> '',
			'desc'		=> '',
			'type'		=> '',
			'default'	=> ''
		);
		*/
		
		
		// ADD YOUR FIELDS HERE //
		
			// **General Options Section		
			$output[] = array(
				'section' 	=> $this->get_slug('field_options'),
				'id'		=> $this->get_slug('field_title_str'),
				'title'		=> 'Field Title',
				'desc'		=> 'This is the custom fields name as it appears on the post edit page.',
				'type'		=> 'text',
				'default'	=> ''
			);
			
			$output[] = array(
				'section' 	=> $this->get_slug('field_options'),
				'id'		=> $this->get_slug('field_key_str'),
				'title'		=> 'Custom Field Key',
				'desc'		=> 'The key required to access the custom field meta data.',
				'type'		=> 'text',
				'default'	=> ''
			);
			
			$output[] = array(
				'section' 	=> $this->get_slug('field_options'),
				'id'		=> $this->get_slug('field_caption_str'),
				'title'		=> 'Field Caption',
				'desc'		=> 'Add user instructions for this field.',
				'type'		=> 'text_area',
				'default'	=> ''
			);
			
			// Field type select radio buttons
			$field_type_choices = array(
				'Text' 			=> 'text',
				'Text Area' 	=> 'text_area',
				'WYSIWYG'		=> 'wysiwyg',
				'Select'		=> 'select',
				'Radio'			=> 'radio',
				'Checkbox'		=> 'checkbox',
				'Multi Checkbox' => 'multi-checkbox',
				'Media Library'	=> 'media',
				'Post Thumbnail' => 'post-thumbnail',
				'Date'			=> 'date'
			);
			
			$output[] = array(
				'section' 	=> $this->get_slug('field_options'),
				'id'		=> $this->get_slug('field_type_str'),
				'title'		=> 'Field Type',
				'desc'		=> '',
				'type'		=> 'radio',
				'default'	=> '',
				'choices'	=> $field_type_choices
			);
			
			$output[] = array(
				'section' 	=> $this->get_slug('field_options'),
				'id'		=> $this->get_slug('field_type_values_str'),
				'title'		=> 'Field Type Values',
				'desc'		=> 'If the field type you selected requires a list of options such as select field. Add them here seperated by commas',
				'type'		=> 'text',
				'default'	=> ''
			);
			
			// **Advanced Options Section
			$output[] = array(
				'section' 	=> $this->get_slug('field_advanced_options'),
				'id'		=> $this->get_slug('field_slug_str'),
				'title'		=> 'Field Slug',
				'desc'		=> 'Permalink slug for this custom field',
				'type'		=> 'text',
				'default'	=> ''
			);
			
			//Create multi-checkbox of all registered user roles//
	        global $wp_roles;
	       	$roles = $wp_roles->get_names();
	 		//Loop roles array and create the array required to output multi-checkboxes using load_fields helper
	 		$role_type_choices = array();
	 		if( !empty($roles) ) {
				foreach( $roles as $slug => $role_name ) {
					$role_type_choices[$role_name] = $this->get_slug($slug . '_int');
				}
			}
	 		$output[] = array(
				'section' 	=> $this->get_slug('field_advanced_options'),
				'id'		=> $this->get_slug('field_user_roles'),
				'title'		=> 'User role access',
				'desc'		=> 'Select the user roles who can use this field',
				'type'		=> 'multi-checkbox',
				'default'	=> '',
				'choices'	=> $role_type_choices
			);
		// END FIELDS //
		
		
		if( !empty($output) ) {
			return $output;
		} else {
			return false;
		}
		
	}
	
	/**
	* Validate
	* 
	* Makes use of the pressoholics framework validation helper to validate/sanitize data
	* Also uses the flash helper to return a message to the user.
	*
	* HOW TO USE:
	*	You should only have to add the fields you wish to validate into the $validate array
	*
	*	Like this: 
	*	$validate[ $fb_url_slug ] = array( 'nice_name' => 'Facebook Page Url', 'type' => 'url', 'message' => 'Invalid URL.', 'empty' => true ,'regex' => null );
	*
	*	'type' tells the validation model how to validate the field e.g phone_us, email, url, password
	*	'empty'	NOT REQUIRED will tell the validator that you are happy to let this field be null
	*	'regex'	This will override the 'type' arg and the validator will use the regex provided to validate the field
	* 
	* @access 	public
	* @author	Ben Moody
	*/
	public function validate( $data ) {

		//Init required Pressoholics Helpers and Models
		global $PrsoFlash;
		global $PrsoValidate;
		
		//Init vars
		$validate = array(); //An array of fields to validate

		//First check to see if required Pressoholic framework plugin methods are installed
		if( is_object( $PrsoValidate ) && method_exists( $PrsoValidate, 'sanitize' ) && method_exists( $PrsoValidate, 'validate' ) ) {
		
			//Init vars
			$validate = array(); //Cache all fields to validate
			
			/***  Create an array of all fields you would like to validate  ***/
			
			//Box Title//
			//$title_slug = $this->get_slug('field_title_str');
			//$validate[ $fb_url_slug ] = array( 'nice_name' => 'Facebook Page Url', 'type' => 'url', 'message' => 'Invalid URL.', 'empty' => true ,'regex' => null );
			
			//Field Title - str required
			$title_slug = $this->get_slug('field_title_str');
			$validate[ $title_slug ] = array( 'nice_name' => 'Field Title', 'type' => null, 'message' => 'Field Title is required', 'empty' => false ,'regex' => null );
			
			//Field key - str required
			$key_slug = $this->get_slug('field_key_str');
			$validate[ $key_slug ] = array( 'nice_name' => 'Field unique key', 'type' => null, 'message' => 'Field Key is required', 'empty' => false ,'regex' => null );
			
			//Field Type - str required
			$type_slug = $this->get_slug('field_type_str');
			$validate[ $type_slug ] = array( 'nice_name' => 'Field type', 'type' => null, 'message' => 'Field Type is required', 'empty' => false ,'regex' => null );
			
			/*** END field array creation ***/
			
			//Call pressoholics validation helper and pass core data array and validation array
			$data = $PrsoValidate->validate( $data, $validate );
			
			//Detect validation errors in data look for error key
			if( isset( $data['error'] ) && $data['error'] ) {
				//Set main page flash message
				$PrsoFlash->set_flash( 'Some fields failed validation. See below for details.', 'error' );
			} else {
				//All is well :)
				$PrsoFlash->set_flash( 'Theme options saved.', 'success' );
			}
			
			return $data;
			
		} else {
			//Missing requried objects, so Pressoholics companion theme plugin not installed :(
			wp_die( __( 'Required plugin missing. Have you installed the Pressoholics Theme Plugin?' ) );		
		}
		
	}
	
	
	
	/**
	*
	* END - OPTIONS PAGE SETUP
	*
	*/
	
	
	/**
	* create_settings
	* 
	* Called in add action to create and output option form sections and fields
	* Makes use of Admin model class to create form field sections then populate those sections
	* with input fields.
	*
	* NOTE: Passes the results of setup_sections and set_fields to the Admin model classes. So setup your
	* 		sections and fields in setup_sections and set_fields methods.
	*
	*/
	public function create_settings() {
		
		//Init vars
		$field_data[ $this->box_options_slug ] = array();
		
		//Register santization callback
		register_setting(
			$this->box_options_slug,
			$this->box_options_slug,
			array( &$this, 'validate' )
		);
		
		global $PrsoAdmin;
		//Setup sections
		$PrsoAdmin->load_sections( $this->setup_sections(), $this->box_options_slug );
	
		//Setup fields and current field values
		if( isset( $this->data['get']['field_key'] ) ){
			$field_data[ $this->box_options_slug ] = $this->data[ $this->box_options_slug ]['fields'][ $this->data['get']['field_key'] ];
		}
		
		$PrsoAdmin->load_fields( $this->setup_fields(), $this->box_options_slug, $field_data );
	}
	
	public function save_field() {
		
		//Init vars
		$box_key 			= null;
		$url				= null;
		
		//Check for form submission
		if( isset( $_POST[ $this->box_options_slug ] ) && !empty( $this->data['get']['box_key'] ) ){
			
			$box_key 	= $this->data['get']['box_key'];
			
			//Sanatize and Validate data
			$clean_data = $this->validate( $_POST[$this->box_options_slug] );
			
			//Check for validation errors
			if( isset( $clean_data['error'] ) && $clean_data['error'] ) {
				//Redirect user back to this page
				$this->plugin_redirect( true, 
					array( 
						'controller' 	=> $this->data['get']['controller'], 
						'action' 		=> 'add', 
						'params' 		=> array( 'box_key' => $box_key )
					) 
				);
			}
			
			//Get current plugin options data
			$this->get_options( $this->box_options_slug );
			
			//ON EDIT - Unset current data from options array - avoid duplication
			if( isset($this->data['get']['field_key']) ) {
				unset( $this->data[$this->box_options_slug][ $this->data['get']['box_key'] ]['fields'][ $this->data['get']['field_key'] ] );
			}
			
			//Now add/update the fields array for this box in the options data
			$this->data[$this->box_options_slug][ $this->data['get']['box_key'] ]['fields'][ $clean_data[ $this->get_slug('field_key_str') ] ] = $clean_data;
			
			//Save options array
			update_option( $this->box_options_slug, $this->data[$this->box_options_slug] );
			
		}
		
		//Redirect to the fields plugin home
		$this->plugin_redirect();
	}
	
}