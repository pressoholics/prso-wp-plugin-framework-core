<?php
/**
 * PrsoFieldsBootstrap
 *
 * Instantiates all required classes for the Pressoholics theme plugin framework
 *
 * E.G Instantiates models, views
 *
 * PHP versions 4 and 5
 *
 * @copyright     Pressoholics (http://pressoholics.com)
 * @link          http://pressoholics.com
 * @package       pressoholics theme framework
 * @since         Pressoholics v 0.1
 */
 
 class PrsoFieldsBootstrap {
 	
 	/**
	* boot
	* 
	* Calls methods to scan models dir and load instances of all valid models found
	* 
	*/
 	public function boot() {
 		
 		//Load common app functions
 		$this->load_app_controller();
 		
 		//Load general app functions
 		$this->load_app_functions();
 		
 	}
 	
 	/**
	* load_app_controller
	* 
	* Loads the app_controller class, which contains common methods shared by all presso plugins
	* 
	*/
 	private function load_app_controller() {
 		
 		if( is_admin() ) {
 			
 			//Find user function class and create instance
			if( file_exists( PRSO_FIELDS_ROOT . '/app_controller.php' ) ) {
			
				//Include admin view file
				include( PRSO_FIELDS_ROOT . '/app_controller.php' );
				
				//Instantiate class
				if( class_exists( 'PrsoFieldsAppController' ) ) {
					$PrsoPluginAppController = new PrsoFieldsAppController();
				}
			
			}
 			
 		}
 		
 	}
 	
 	/**
	* load_app_functions
	* 
	* Loads the app_functions class, which contains all custom methods for this app
	* 
	*/
 	private function load_app_functions() {
 		
 		if( is_admin() ) {
 			
 			//Find user function class and create instance
			if( file_exists( PRSO_FIELDS_ROOT . '/functions.php' ) ) {
			
				//Include admin view file
				include( PRSO_FIELDS_ROOT . '/functions.php' );
				
				//Instantiate class
				if( class_exists( 'PrsoFieldsFunctions' ) ) {
					$PrsoPluginFunctions = new PrsoFieldsFunctions();
				}
			
			}
 			
 		}
 		
 	}
 	
 }