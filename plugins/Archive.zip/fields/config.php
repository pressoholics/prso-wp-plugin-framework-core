<?php
/**
 * Config
 *
 * Sets all constant definitions for the Pressoholics theme plugin framwork
 *
 * PHP versions 4 and 5
 *
 * @copyright     Pressoholics (http://pressoholics.com)
 * @link          http://pressoholics.com
 * @package       pressoholics theme framework
 * @since         Pressoholics v 0.1
 */

/**
* Define a unique slug to prepend to all wordpress database keys to ensure
* there are no conflicts
*
*/
if (!defined('PRSO_FIELDS_SLUG')) {
	define('PRSO_FIELDS_SLUG', 'prso_fields_');
}
 
/**
* The full path to the directory which holds "presso_framework", WITHOUT a trailing DS.
*
*/
if (!defined('PRSO_FIELDS_ROOT')) {
	define( 'PRSO_FIELDS_ROOT', dirname(__FILE__) );
}

/**
* The full path to the directory which holds "views", WITHOUT a trailing DS.
*
*/
if (!defined('PRSO_FIELDS_VIEWS')) {
	define('PRSO_FIELDS_VIEWS', PRSO_FIELDS_ROOT . '/views');
}

/**
* The full path to the directory which holds "includes", WITHOUT a trailing DS.
*
*/
if (!defined('PRSO_FIELDS_INCLUDES')) {
	define('PRSO_FIELDS_INCLUDES', PRSO_FIELDS_ROOT . '/includes');
}

/**
* The full path to the Presso Field Plugin Config File.
*
*/
if (!defined('PRSO_FIELDS_CONFIG')) {
	define('PRSO_FIELDS_CONFIG', PRSO_FIELDS_ROOT . '/config.php');
}