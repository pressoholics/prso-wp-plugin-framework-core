<?php
/**
 * General App Functions
 *
 * Usually contains general functions required to get the plugin started such as request_router
 *
 * Use the Wordpress API call's within __construct to call your methods:
 *	//Action hook example
 *	add_action( 'init', array( &$this, 'test' ) ); 
 *
 * Contents:
 * 
 *
 */
class PrsoFieldsFunctions extends PrsoFieldsAppController {
	
	function __construct() {
		
		//Add child options page to presso theme plugin
 		add_action('admin_menu', array( &$this, 'boot' ));
 		
 		//Add custom field boxes and fields to posts
 		add_action( 'admin_init', array( &$this, 'add_field_boxes' ) );
 		
 		//Call wp function to setup saving meta box
		add_action( 'save_post', array( &$this, 'save_fields' ) );
		
		//Enqueue any custom scripts or styles
		add_action( 'admin_init', array( &$this, 'enqueue_scripts' ) );
		
		//Add any custom filter
		add_action( 'admin_init', array( &$this, 'add_filters' ) );
		
	}
	
	public function boot() {

		//Add submenu page
		add_submenu_page(
			$this->plugin_parent_page_slug,
			$this->plugin_index_page_title,
			'Fields',
			'administrator',
			$this->get_slug( 'plugin_index_page_slug' ),
			array( &$this, 'request_router' )
		);
		
	}
	
	public function enqueue_scripts() {
		
		//Enqueue fields plugin styles
		wp_enqueue_style( 'presso-fields-style', plugins_url( '/styles/forms.css' , PRSO_FIELDS_CONFIG ) );
		
	}
	
	public function add_filters() {
		
	}
	
	/**
	* add_field_boxes
	* 
	* Loops the plugins data array, detects any field boxes then loops their settings (context, post type, title, ect)
	* then calls add_meta_box() to output the field box.
	*
	* NOTE:
	*		add_meta_box() uses $this->add_fields as a callback and passes it the unique key of the field box currenlty being drawn
	*		the box key is used by $this->add_fields to find and draw the box's fields.
	*
	* 
	* @access 	public
	* @author	Ben Moody
	*/
	public function add_field_boxes() {
	
		//Get all custom fields options data and cache in $this->data for later
		$this->get_options( $this->get_slug( 'box_options_slug' ) );
		
		//Check for any new field boxes and then call method to build the meta box
		if( !empty( $this->data[ $this->get_slug( 'box_options_slug' ) ] ) && is_array( $this->data[ $this->get_slug( 'box_options_slug' ) ] ) ) {
			
			//Loop each field meta box option and call method to output the fields
			foreach( $this->data[ $this->get_slug( 'box_options_slug' ) ] as $box_key => $box_data_array ) {
				
				//Loop the post types this box should appear on and call wp function to add box to each type
				foreach( $box_data_array[ $this->get_slug('box_post_types') ] as $key => $post_type ) {
					
					//Detect the requested box position on the edit screen (left = normal, right = side)
					$context = 'normal';
					if( isset( $box_data_array[ $this->get_slug('box_position_str') ] ) && !empty( $box_data_array[ $this->get_slug('box_position_str') ] ) ) {
						if( $box_data_array[ $this->get_slug('box_position_str') ] === 'left' ) {
							$context = 'normal';
						} else {
							$context = 'side';
						}
					}
					
					//Get an array of all post types registered for this custom field box
					$post_types_array = $this->detect_post_type( $box_key, true );
					
					//Now loop each registered post type, calling add_meta_box for each one
					if( is_array($post_types_array) ) {
						
						foreach( $post_types_array as $key => $reg_post_type ) {
							//Format box title
							$box_title = ucfirst( $box_data_array[ $this->get_slug('field_title_str') ] );
					
							//Before we call add_meta_box, lets check if we have any fields that require scripts or filters to run at admin_init
							$this->field_admin_init_tasks( $box_key, $reg_post_type );
					
							//Call wp function to add meta box
							add_meta_box( $box_key, $box_title, array( &$this, 'add_fields' ), $reg_post_type, $context, 'default', array( 'box_key' => $box_key ) );
						}
						
					}
					
				}
				
			}
			
		}
		
	}
	
	private function field_admin_init_tasks( $box_key = NULL, $post_type = NULL ) {
		
		//Init vars
		$fields_data 	= array();
		$field_args		= array();
		
		if( !empty($box_key) ) {
		
			//Cache data for all custom fields
			if( isset($this->data[$this->get_slug('box_options_slug')][$box_key]['fields']) ) {
				$fields_data = $this->data[$this->get_slug('box_options_slug')][$box_key]['fields'];
			}
			
			if( !empty($fields_data) ) {
				//Loop fields data array and check for any field types that will require admin_init actions
				foreach( $fields_data as $field_key => $field_vals ) {
					//Cache the field type
					$field_args['type'] = $field_vals[$this->get_slug('field_type_str')];
					
					//Cache field title
					$field_args['title'] = $field_vals[$this->get_slug('field_title_str')];
					
					//Cache field key
					$field_args['key'] = $field_vals[$this->get_slug('field_key_str')];
					
					//Cache field caption
					$field_args['caption'] = $field_vals[ $this->get_slug('field_caption_str') ];
					
					//Detect field type that require admin_init actions
					switch( $field_args['type'] ) {
						case 'post-thumbnail':
							//Set var required to Enqueue script for multi_post_thumbnails Class
							$multi_post_js_url	= plugins_url( '/js/multi-post-thumbnails-admin.js' , PRSO_FIELDS_CONFIG );
							
							//Call method to handle multi post thumbnails
							$thumb_args = array(
								'label' => $field_args['title'],
								'id' => $field_args['key'],
								'post_type' => $post_type,
								'priority' => 'low',
								'admin_init' => true,
								'js_url'	=> $multi_post_js_url,
								'caption' => $field_args['caption']
							);
							
							$this->multi_post_thumbnails( $thumb_args );
							break;
					}
				}
			}
			
		}
		
	}
	
	/**
	* add_fields
	* 
	* Accepts the current field box's unique data array key from add_meta_box() and uses it
	* to find any fields associated with the current field box.
	*
	* If fields are found, we loop each field, cache the field args and pass required args to $PrsoAdmin->create_settings_fields() model
	* which will echo out the html for that field type.
	*
	* 
	* @access 	public
	* @author	Ben Moody
	*/
	public function add_fields( $post, $metabox ) {
		
		//Init vars
		global $PrsoAdmin;
		$box_key 		= NULL;
		$fields_data	= array();
		$field_args		= array(
			'title'		=> '',
			'caption'	=> '',
			'key'		=> '',
			'type'		=> '',
			'type_vals'	=> '',
			'slug'		=> ''
		);
		$current_field_meta = null;
		
		//SECURITY NONCE
		wp_nonce_field( plugin_basename( __FILE__ ), $this->get_slug( 'box_options_slug' ) );
		
		//Cache field box key
		if( isset($metabox['args']['box_key']) ) {
			$box_key = $metabox['args']['box_key'];
		}
		
		//Cache data for all custom fields
		if( isset($this->data[$this->get_slug('box_options_slug')][$box_key]['fields']) ) {
			$fields_data = $this->data[$this->get_slug('box_options_slug')][$box_key]['fields'];
		}
		
		//Check all required vals are present
		if( !empty($box_key) && !empty($fields_data) ) {
			//Loop fields data and cache the args for each field
			foreach( $fields_data as $field_key => $field_vals ) {
				
				//Cache field title
				$field_args['title'] = $field_vals[ $this->get_slug('field_title_str') ];
				
				//Cache field caption
				$field_args['caption'] = $field_vals[ $this->get_slug('field_caption_str') ];
				
				//Cache field key
				$field_args['key'] = $field_vals[ $this->get_slug('field_key_str') ];
				
				//Cache field type
				$field_args['type'] = $field_vals[ $this->get_slug('field_type_str') ];
				
				//Cache field values
				$field_args['type_vals'] = $field_vals[ $this->get_slug('field_type_values_str') ];
				
				//Cache field slug
				$field_args['slug'] = $field_vals[ $this->get_slug('field_slug_str') ];
				
				//Get current meta data for this field
				$current_field_meta = get_post_meta( $post->ID, $this->get_slug( $field_args['key'] ), true );
				
				//Cache meta box position
				$box_position = NULL;
				if( isset($this->data[$this->get_slug('box_options_slug')][$box_key]['prso_fields_box_position_str']) ) {
					$box_position = $this->data[$this->get_slug('box_options_slug')][$box_key]['prso_fields_box_position_str'];
				}
				
				//First detect if this field is an extra featured image post thumbnail
				if( $field_args['type'] == 'post-thumbnail' ) {
					
					//As custom fields can be on multiple post types, lets confirm that we should display this post type
					if( $this->detect_post_type( $box_key ) ) {
						global $post_type;
						
						//Call method to handle multi post thumbnails
						$thumb_args = array(
							'label' => $field_args['title'],
							'id' => $field_args['key'],
							'post_type' => $post_type,
							'priority' => 'low',
							'box_position' => $box_position,
							'caption' => $field_args['caption']
						);
						
						$this->multi_post_thumbnails( $thumb_args );
					}
					
				} else {
					
					//Call create_settings_fields method in Admin model to output field html
					$create_field_args = array(
						'id'		=> $this->get_slug( $field_args['key'] ),
						'title'		=> $field_args['title'],
						'desc'		=> $field_args['caption'],
						'type'		=> $field_args['type'],
						'default'	=> $current_field_meta,
						'class'		=> 'presso-field-' . $field_args['type'],
						'page'		=> 'post',
						'choices'	=> $field_args['type_vals']
					);
					
					//Wrap the field html in div with wordpress post edit page default css classes
					echo "<div class='mf_field_wrapper mf_field_{$this->get_slug($field_args['key'])} {$box_position}'>";
					$PrsoAdmin->create_settings_fields( $create_field_args );
					echo "</div>";
					
				}
				
			}
		} else {
			echo "<p>There are no custom fields for this field box</p>";
		}
		
	}
	
	private function detect_post_type( $box_key = NULL, $return_all_types = false ) {
		
		//Cache current edit page post type
		global $post_type;
		
		//Init vars
		$box_post_types = array();
		$post_types = array();
		
		//Cache box_post_types
		if( isset($this->data[$this->get_slug('box_options_slug')][$box_key]['prso_fields_box_post_types']) ) {
			$box_post_types = $this->data[$this->get_slug('box_options_slug')][$box_key]['prso_fields_box_post_types'];
		}
		
		//Extract post type strings from $box_post_types array
		if( is_array($box_post_types) ) {
			
			foreach( $box_post_types as $key => $val ) {
				
				$temp_post_type = array();
				
				$temp_post_type = explode('_', $val);
				
				if( isset($temp_post_type[2]) ) {
					$post_types[] = $temp_post_type[2];
				}
				
			}
		
		}
		
		//Should we just return the post types we have found?
		if( $return_all_types ) {
			return $post_types;
		}
		
		//If not then let's check to see if the current admin edit page post type is in our post_types array
		if( in_array($post_type, $post_types) ) {
			return true;
		} else {
			return false;
		}
		
	}
	
	private function multi_post_thumbnails( $thumb_args = array() ) {
		
		$multi_post_include_path 	= PRSO_FIELDS_INCLUDES . '/multi-post-thumbnails.php';
		
		if( !isset($thumb_args['label'], $thumb_args['id'], $thumb_args['post_type']) ) {
			if (WP_DEBUG) {
				trigger_error(sprintf("The 'label' and 'id' and 'post_type' values of the 'thumb_args' parameter of '%s::%s()' are required", __CLASS__, __FUNCTION__));
			}
			return;
		}
		
		//Include mulit-post-thumbnails.php
		if( file_exists($multi_post_include_path) ) {
			include_once($multi_post_include_path);
			//Check class exsists
			if( class_exists('MultiPostThumbnails') ) {
				//Create instance of class and pass thumb_args
				new MultiPostThumbnails( $thumb_args );
			}
		}
		
	}
	
	/* When the post is saved, saves our custom data */
	public function save_fields( $post_id ) {
		//Init vars
		$custom_field_key = NULL;
		$clean_meta_value = NULL; //Cache sanitized data strings
		
		// verify if this is an auto save routine. 
		// If it is our form has not been submitted, so we dont want to do anything
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
		  return;

	  	if( isset($_POST['post_type']) ) {
			// Check permissions
			if ( 'page' == $_POST['post_type'] ) {
				if ( !current_user_can( 'edit_page', $post_id ) )
				    return;
			} else {
				if ( !current_user_can( 'edit_post', $post_id ) )
				    return;
			}
			
			// OK, we're authenticated: lets get all custom posts ad check for data
			$this->get_options( $this->get_slug( 'box_options_slug' ) );
			
			//Check for any new field boxes and then call method to build the meta box
			if( !empty( $this->data[ $this->get_slug( 'box_options_slug' ) ] ) && is_array( $this->data[ $this->get_slug( 'box_options_slug' ) ] ) ) {
				//Loop each custom field box
				foreach( $this->data[ $this->get_slug( 'box_options_slug' ) ] as $box_key => $box_data ) {
					//Loop each fields and use key to check post for field submissions
					foreach( $box_data['fields'] as $field_key => $field_data ) {
						//Cache field key (form field name) for current custom field
						$custom_field_key = $this->get_slug( $field_key );

						//Save field data if not empty
						if( isset($_POST[ $custom_field_key ]) ) {
							//Strip evil tags and maintain post standard html tags
							$clean_meta_value = wp_kses_post( $_POST[ $custom_field_key ] );
							
							//Save clean data
							if( !add_post_meta($post_id, $custom_field_key, $clean_meta_value, true) ) {
								update_post_meta($post_id, $custom_field_key, $clean_meta_value);
							}				
						}	
					}
				}
				
			}
		}
	}

}